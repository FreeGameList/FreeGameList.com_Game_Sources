﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PauseScreen : ScreenBase
{
	#region constants
	
	#endregion
	
	#region vars
	
	#endregion
	
	#region properties

	public override ScreenID ID
	{
		get { return ScreenID.Pause; }
	}

	#endregion
	
	#region init

	protected override void Awake()
	{
		base.Awake();
	}
	
	// Use this for initialization
	protected override void Start()
	{
		base.Start();
	}
	
	#endregion

	#region update
	
	// Update is called once per frame
	protected override void Update()
	{
		base.Update();
	}
	
	#endregion
	
	#region protected methods
	
	
	#endregion
	
	#region public methods
	
	#endregion
}
