﻿public class HumanPlayer : Player
{
}