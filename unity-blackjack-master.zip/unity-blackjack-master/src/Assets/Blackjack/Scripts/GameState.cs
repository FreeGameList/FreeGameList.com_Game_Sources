﻿public enum GameState
{
    None,
    HumanTurn,
    ComputerTurn,
    HumanWon,
    ComputerWon,
    Draw,
}