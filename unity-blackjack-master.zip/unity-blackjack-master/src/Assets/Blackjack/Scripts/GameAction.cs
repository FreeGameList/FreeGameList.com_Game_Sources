﻿public enum GameAction
{
    None,
    Deal,
    HitAndStand,
    NewGame
}