game & screenshots can be found:
    /dropbox/toobz

Office machine has mappy in
    D:\archive\development\mapwin1423
Home machine its
	D:\programs\Allegro\TGF\odds