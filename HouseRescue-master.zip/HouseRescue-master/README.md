# HouseRescue
Fun Unity platformer game made for Global Game Jam 2019


![](https://raw.githubusercontent.com/RodrigoRosmaninho/HouseRescue/master/Assets/Resources/scene%20sprites/Menu-back.png)


[https://globalgamejam.org/2019/games/home-rescue](https://globalgamejam.org/2019/games/home-rescue)

What is really your home? Sometimes all the things you have going on in your life can drag you away from what really matters. 
Peanut just woke up in his sweat home. But something is just not right. He can't find his little brother anywere nor any other member of his family. 
Peanut is about to begin the bigest adventure of his life too find his family. Can you help him rescue his loved ones?

Made with the Unity Engine and C# scripting

Playable WebGL version available [here](https://rodrigorosmaninho.github.io/HouseRescue/). Go try it!

## Credits:
Development: 
- [Rodrigo Rosmaninho (me)](https://github.com/RodrigoRosmaninho)
- [Daniel Correia](https://github.com/danielcorreia13)

Level Design:
- Alexandre Correia

Art:
- Diogo Correia
