using UnityEngine;
using UnityEditor;

public abstract class Enemy : MonoBehaviour {
     public float velocity;

    public virtual void Start() {
       
    }

    public virtual void FixedUpdate() {
        
        
    }







}
