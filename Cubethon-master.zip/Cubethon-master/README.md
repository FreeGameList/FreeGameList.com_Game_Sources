Game link - [Cubethon](https://cubethon.glitch.me/)
